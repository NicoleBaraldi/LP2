﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class Frmexercicio3 : Form
    {
        public Frmexercicio3()
        {
            InitializeComponent();
        }

        private void Frmexercicio3_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);
            while (posicao >= 0)
            {

                txtpalavra2.Text = txtpalavra2.Text.Substring(0, posicao) +
                        txtpalavra2.Text.Substring(posicao + txtpalavra1.Text.Length,
                        txtpalavra2.Text.Length - posicao - txtpalavra1.Text.Length);
                posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);
            }
        }

        private void btnremover2_Click(object sender, EventArgs e)
        {
            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text, "");
        }

        private void btninverte_Click(object sender, EventArgs e)
        {
            char[] meuArray = txtpalavra1.Text.ToCharArray();
            Array.Reverse(meuArray);


            foreach (char c in meuArray) 
            {
                txtpalavra2.Text += c;
                                   
            }
        }
    }
}
