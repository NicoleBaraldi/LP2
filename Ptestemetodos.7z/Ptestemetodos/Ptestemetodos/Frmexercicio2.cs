﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class Frmexercicio2 : Form
    {
        public Frmexercicio2()
        {
            InitializeComponent();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtpalavra1.Text, txtpalavra2.Text, true) == 0)
                MessageBox.Show("As palavras são iguais");
            else
                MessageBox.Show("As palavras são diferentes");
                    
        }

        private void btninserir1_Click(object sender, EventArgs e)
        {
            int metade = txtpalavra2.Text.Length / 2;

            txtpalavra2.Text = txtpalavra2.Text.Substring(0, metade) +
                        txtpalavra1.Text +
                        txtpalavra2.Text.Substring(metade, txtpalavra2.Text.Length - metade);
        }
    }
}
