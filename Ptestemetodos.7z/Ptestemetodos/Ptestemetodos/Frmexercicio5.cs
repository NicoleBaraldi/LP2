﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class Frmexercicio5 : Form
    {
        public Frmexercicio5()
        {
            InitializeComponent();
        }

        private void Frmexercicio5_Load(object sender, EventArgs e)
        {
            Frmexercicio5 objFrm5 = new Frmexercicio5();
            objFrm5.MdiParent = this;

            objFrm5.WindowState = FormWindowState.Maximized;

            objFrm5.Show();
        }
    }
}
