﻿
namespace Ptestemetodos
{
    partial class Frmexercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.btnverificar = new System.Windows.Forms.Button();
            this.btninserir1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(112, 84);
            this.lblpalavra1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(94, 25);
            this.lblpalavra1.TabIndex = 0;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(112, 167);
            this.lblpalavra2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(94, 25);
            this.lblpalavra2.TabIndex = 1;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(258, 84);
            this.txtpalavra1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(198, 30);
            this.txtpalavra1.TabIndex = 2;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(258, 167);
            this.txtpalavra2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(198, 30);
            this.txtpalavra2.TabIndex = 3;
            // 
            // btninserir2
            // 
            this.btninserir2.Location = new System.Drawing.Point(437, 309);
            this.btninserir2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(198, 62);
            this.btninserir2.TabIndex = 4;
            this.btninserir2.Text = "Inserir 2 asteriscos no meio do 1º";
            this.btninserir2.UseVisualStyleBackColor = true;
            // 
            // btnverificar
            // 
            this.btnverificar.Location = new System.Drawing.Point(117, 309);
            this.btnverificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(130, 62);
            this.btnverificar.TabIndex = 5;
            this.btnverificar.Text = "Testar igualdade";
            this.btnverificar.UseVisualStyleBackColor = true;
            this.btnverificar.Click += new System.EventHandler(this.btnverificar_Click);
            // 
            // btninserir1
            // 
            this.btninserir1.Location = new System.Drawing.Point(273, 309);
            this.btninserir1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btninserir1.Name = "btninserir1";
            this.btninserir1.Size = new System.Drawing.Size(156, 62);
            this.btninserir1.TabIndex = 6;
            this.btninserir1.Text = "Inserir o 1º no meio do 2º";
            this.btninserir1.UseVisualStyleBackColor = true;
            this.btninserir1.Click += new System.EventHandler(this.btninserir1_Click);
            // 
            // Frmexercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 703);
            this.Controls.Add(this.btninserir1);
            this.Controls.Add(this.btnverificar);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frmexercicio2";
            this.Text = "Frmexercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btninserir2;
        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.Button btninserir1;
    }
}