﻿
namespace Ptestemetodos
{
    partial class Frmexercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btnremover = new System.Windows.Forms.Button();
            this.btnremover2 = new System.Windows.Forms.Button();
            this.btninverte = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(20, 104);
            this.lblpalavra1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(86, 24);
            this.lblpalavra1.TabIndex = 0;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(20, 187);
            this.lblpalavra2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(86, 24);
            this.lblpalavra2.TabIndex = 1;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(138, 104);
            this.txtpalavra1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(308, 28);
            this.txtpalavra1.TabIndex = 2;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(138, 187);
            this.txtpalavra2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(308, 28);
            this.txtpalavra2.TabIndex = 3;
            // 
            // btnremover
            // 
            this.btnremover.Location = new System.Drawing.Point(24, 319);
            this.btnremover.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnremover.Name = "btnremover";
            this.btnremover.Size = new System.Drawing.Size(208, 81);
            this.btnremover.TabIndex = 4;
            this.btnremover.Text = "Remover Ocorrências";
            this.btnremover.UseVisualStyleBackColor = true;
            this.btnremover.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnremover2
            // 
            this.btnremover2.Location = new System.Drawing.Point(239, 319);
            this.btnremover2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnremover2.Name = "btnremover2";
            this.btnremover2.Size = new System.Drawing.Size(208, 81);
            this.btnremover2.TabIndex = 5;
            this.btnremover2.Text = "Remover Ocorrênicas(Replace)";
            this.btnremover2.UseVisualStyleBackColor = true;
            this.btnremover2.Click += new System.EventHandler(this.btnremover2_Click);
            // 
            // btninverte
            // 
            this.btninverte.Location = new System.Drawing.Point(454, 319);
            this.btninverte.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btninverte.Name = "btninverte";
            this.btninverte.Size = new System.Drawing.Size(208, 81);
            this.btninverte.TabIndex = 6;
            this.btninverte.Text = "Inverte";
            this.btninverte.UseVisualStyleBackColor = true;
            this.btninverte.Click += new System.EventHandler(this.btninverte_Click);
            // 
            // Frmexercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 619);
            this.Controls.Add(this.btninverte);
            this.Controls.Add(this.btnremover2);
            this.Controls.Add(this.btnremover);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frmexercicio3";
            this.Text = "Frmexercicio3";
            this.Load += new System.EventHandler(this.Frmexercicio3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btnremover;
        private System.Windows.Forms.Button btnremover2;
        private System.Windows.Forms.Button btninverte;
    }
}