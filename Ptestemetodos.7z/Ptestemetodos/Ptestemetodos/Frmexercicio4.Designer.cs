﻿
namespace Ptestemetodos
{
    partial class Frmexercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtftexto = new System.Windows.Forms.RichTextBox();
            this.btnnumeros = new System.Windows.Forms.Button();
            this.btnbranco = new System.Windows.Forms.Button();
            this.btnletras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtftexto
            // 
            this.rtftexto.Location = new System.Drawing.Point(78, 60);
            this.rtftexto.Name = "rtftexto";
            this.rtftexto.Size = new System.Drawing.Size(399, 176);
            this.rtftexto.TabIndex = 0;
            this.rtftexto.Text = "";
            // 
            // btnnumeros
            // 
            this.btnnumeros.Location = new System.Drawing.Point(49, 242);
            this.btnnumeros.Name = "btnnumeros";
            this.btnnumeros.Size = new System.Drawing.Size(105, 48);
            this.btnnumeros.TabIndex = 1;
            this.btnnumeros.Text = "Números";
            this.btnnumeros.UseVisualStyleBackColor = true;
            this.btnnumeros.Click += new System.EventHandler(this.btnnumeros_Click);
            // 
            // btnbranco
            // 
            this.btnbranco.Location = new System.Drawing.Point(49, 315);
            this.btnbranco.Name = "btnbranco";
            this.btnbranco.Size = new System.Drawing.Size(105, 48);
            this.btnbranco.TabIndex = 2;
            this.btnbranco.Text = "Espaço em branco";
            this.btnbranco.UseVisualStyleBackColor = true;
            this.btnbranco.Click += new System.EventHandler(this.btnbranco_Click);
            // 
            // btnletras
            // 
            this.btnletras.Location = new System.Drawing.Point(49, 390);
            this.btnletras.Name = "btnletras";
            this.btnletras.Size = new System.Drawing.Size(105, 48);
            this.btnletras.TabIndex = 3;
            this.btnletras.Text = "Letras";
            this.btnletras.UseVisualStyleBackColor = true;
            // 
            // Frmexercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnletras);
            this.Controls.Add(this.btnbranco);
            this.Controls.Add(this.btnnumeros);
            this.Controls.Add(this.rtftexto);
            this.Name = "Frmexercicio4";
            this.Text = "Frmexercicio4";
            this.Load += new System.EventHandler(this.Frmexercicio4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtftexto;
        private System.Windows.Forms.Button btnnumeros;
        private System.Windows.Forms.Button btnbranco;
        private System.Windows.Forms.Button btnletras;
    }
}