﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class Frmexercicio4 : Form
    {
        public Frmexercicio4()
        {
            InitializeComponent();
        }

        private void Frmexercicio4_Load(object sender, EventArgs e)
        {
            Frmexercicio4 objFrm4 = new Frmexercicio4();
            objFrm4.MdiParent = this;

            objFrm4.WindowState = FormWindowState.Maximized;

            objFrm4.Show();
        }

        private void btnnumeros_Click(object sender, EventArgs e)
        {

            int letra;
            int quantidade = 0;

            for (letra = 0; letra < rtftexto.Text.Length; letra++)
            {
                if(char.IsDigit(rtftexto.Text[letra]))
                {
                    quantidade++;

                }

            }

            MessageBox.Show(quantidade.ToString());



        }

        private void btnbranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            if(rtftexto.Text != "")
                while(posicao <rtftexto.Text.Length)
                {

                if (char.IsWhiteSpace(rtftexto.Text[posicao]))
                {
                        break;
                }

                 posicao++;

                }

            MessageBox.Show(posicao.ToString());
        }
    }
}
