﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrou no menu copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrou no menu colar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Form fc = Application.OpenForms["frmExercicio2"];

            if (fc != null)
                fc.Close();

            Frmexercicio2 objFrm2 = new Frmexercicio2();
            objFrm2.MdiParent = this;

            objFrm2.WindowState = FormWindowState.Maximized;

            objFrm2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio3"];

            if (fc != null)
                fc.Close();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio4"];

            if (fc != null)
                fc.Close();

            Frmexercicio4 objFrm4 = new Frmexercicio4();
            objFrm4.MdiParent = this;

            objFrm4.WindowState = FormWindowState.Maximized;

            objFrm4.Show();
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio5"];

            if (fc != null)
                fc.Close();

            Frmexercicio5 objFrm5 = new Frmexercicio5();
            objFrm5.MdiParent = this;

            objFrm5.WindowState = FormWindowState.Maximized;

            objFrm5.Show();
        }
    }
}
